package com.example.to_do_list;

import android.content.Context;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;

import java.util.Objects;

public class TaskAdapter  extends ArrayAdapter<Task> {
    public TaskAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }
