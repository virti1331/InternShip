package com.example.to_do_list;

public class Task {
    private String title;
    private String description;
    private boolean isCompleted;

    public void setTitle(String taskTitle) {
    }

    // Constructors, getters, and setters
}
