package com.DataFlair.dataflairtodolist.task_database;public class todoAdapter {
}
